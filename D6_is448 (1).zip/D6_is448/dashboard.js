//Author: Emilien Tchuosi
"use strict";

//validate form input for time and numbers :) 
function timeFormat(input) {
  input.value = input.value.replace(/[^0-9:]/g, '');
}

//calculate total hours for the week
function calculateTotalHours() {
    var totalHours = "00:00";
    
    var rows = document.querySelectorAll("table tr");
    
    for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        var days = row.querySelectorAll("input[type='text']");
        
        for (var j = 0; j < days.length; j++) {
            var hoursInput = days[j];
            var hours = hoursInput.value.trim();
            
            if (hours !== "") {
                var timeParts = hours.split(":");
                var hoursValue = parseInt(timeParts[0]);
                var minutesValue = parseInt(timeParts[1]);
            
                if (!isNaN(hoursValue) && !isNaN(minutesValue)) {
                    totalHours = addTime(totalHours, hours);
                }
            }
        }
    }
    
    document.getElementById("pay-h").value = totalHours;
}

//part of the calculateTotalHours function
function addTime(time1, time2) {
    var time1Parts = time1.split(":");
    var time2Parts = time2.split(":");
  
    var hours1 = parseInt(time1Parts[0]);
    var minutes1 = parseInt(time1Parts[1]);
  
    var hours2 = parseInt(time2Parts[0]);
    var minutes2 = parseInt(time2Parts[1]);
  
    var totalMinutes = minutes1 + minutes2;
    var additionalHours = Math.floor(totalMinutes / 60);
    var remainingMinutes = totalMinutes % 60;
  
    var totalHours = hours1 + hours2 + additionalHours;
  
    return padZero(totalHours) + ":" + padZero(remainingMinutes);
}

//adds a 0 if the number is less than 10
function padZero(num) {
    return (num < 10 ? "0" : "") + num;
}

// Function to add a new row to the table
function addRow() {
  var table = document.querySelector('.timesheet-form tbody');
  var newRow = document.createElement('tr');

  newRow.innerHTML = `
    <td>
      <label for="project"></label>
      <input type="text" name="project" id="project" placeholder="Project..." required/>
    </td>
    <td>
      <label for="task"></label>
      <input type="text" name="task" id="task" placeholder="Task..." required/>
    </td>
    <td>
      <label for="sun-h"></label>
      <input type="text" name="sun-h" id="sun-h" placeholder="00:00" oninput="timeFormat(this), calculateTotalHours()" required />
    </td>
    <td>
      <label for="mon-h"></label>
      <input type="text" name="mon-h" id="mon-h" placeholder="00:00" oninput="timeFormat(this), calculateTotalHours()" required />
    </td>
    <td>
      <label for="tue-h"></label>
      <input type="text" name="tue-h" id="tue-h" placeholder="00:00" oninput="timeFormat(this), calculateTotalHours()" required />
    </td>
    <td>
      <label for="wed-h"></label>
      <input type="text" name="wed-h" id="wed-h" placeholder="00:00" oninput="timeFormat(this), calculateTotalHours()" required />
    </td>
    <td>
      <label for="thurs-h"></label>
      <input type="text" name="thurs-h" id="thurs-h" placeholder="00:00" oninput="timeFormat(this), calculateTotalHours()" required />
    </td>
    <td>
      <label for="fri-h"></label>
      <input type="text" name="fri-h" id="fri-h" placeholder="00:00" oninput="timeFormat(this), calculateTotalHours()" required />
    </td>
    <td>
      <label for="sat-h"></label>
      <input type="text" name="sat-h" id="sat-h" placeholder="00:00" oninput="timeFormat(this), calculateTotalHours()" required />
    </td>
    <td>
      <img src="delete.svg" alt="bin" class="del-btn" onclick="deleteRow(this)" />
    </td>
  `;

  table.appendChild(newRow);
  
}

// Function to delete a row from the table
function deleteRow(row) {
  var table = document.querySelector('.timesheet-form tbody');
  var parentRow = row.parentNode.parentNode;
  table.removeChild(parentRow);

  calculateTotalHours();
}