 
<!DOCTYPE html>
<html lang="en"> 
<link rel="stylesheet" href="createaccount.css">
<?php
// verifies if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the form data
  $name = $_POST["name"];
  $email = $_POST["email"];
  $password = $_POST["pass"];
  $role = $_POST["role"];
  $employer_name = $_POST["employ"];



  // Connects to the database
  $conn = new mysqli("studentdb-maria.gl.umbc.edu", "cboyer5", "cboyer5", "cboyer5");

  // checks the connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Inserts the entered form data into the database
  $sql = "INSERT INTO CreateAccount (name, email, password, role, employer_name) VALUES ('$name', '$email', '$password', '$role', '$employer_name')";
  if ($conn->query($sql) === TRUE) {
    echo "Thanks for signing up! your account has been created. ";
	
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

  // ends database connection
  $conn->close();
}
?>
login  <a href="login.html">Here</a>
</html>