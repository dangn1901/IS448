<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Timesheets</title>
	<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
  </head>
  <body>
    <!--sidebar-->
    <div class="sidebar">
      <div class="logo">
        <img src="/images/clock.svg" alt="image of a clock" />
        <h2>Timeo</h2>
      </div>
      <a href="emp_dash.html">Dashboard</a>
      <a href="emp_mytimesheet.html">My Timesheet</a>
      <a href=""> Logout</a>

      <div class="side-footer">
        <img src="/images/user.svg" alt="picture of a random person" />
        <h3 class="username">Username</h3>
      </div>
      <small>Version 1.0.0</small>
    </div>

    <!--Header-->
    <div class="main-nav">
      <h3 class="title">My Timesheets</h3>
      <div class="search-bar">
        <img src="/images/search.svg" alt="search icon" class="search" />
        <input type="text" name="search" id="search" placeholder="Search..." />
      </div>
    </div>

    <!--Table to be populated-->
    <table id="table">
      <thead>
        <tr>
          <th>Timesheet id</th>
          <th>Week</th>
          <th>Hours</th>
          <th>Pay</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <!-- <td>Timesheet 00</td> -->
          <!-- <td>Jan 01 - Dec 31</td> -->
          <!-- <td>8760</td> -->
          <!-- <td>$43800</td> -->
          <!-- <td> -->
            <!--Dropdown for options-->
            <div class="drop">
              <div class="options">&#x2022;&#x2022;&#x2022;</div>
              <div class="drop-con">
                <a href="">View</a>
                <a href="">Edit</a>
                <a href="">Export</a>
                <a href="" style="color: red">Delete</a>
              </div>
            </div>
          <!-- </td> -->
        </tr>
        <!--PHP code to add rows from database goes here-->
		<?php
		require_once "emp_mytimesheet.php";
	// Connect to the database
$conn = mysqli_connect("studentdb-maria.gl.umbc.edu", "cboyer5", "cboyer5", "cboyer5");

// Check if the connection was successful
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Update a timesheet entry
if (isset($_POST["id"]) && isset($_POST["week"]) && isset($_POST["hours"]) && isset($_POST["pay_rate"])) {
  $id = $_POST["id"];
  $week = $_POST["week"];
  $hours = $_POST["hours"];
  $pay_rate = $_POST["pay_rate"];

  // Update the timesheet entry in the database
  $sql = "UPDATE timesheet SET week='$week', hours='$hours', pay_rate='$pay_rate' WHERE id='$id'";
  if (mysqli_query($conn, $sql)) {
    echo "Timesheet entry updated successfully.";
  } else {
    echo "Error updating timesheet entry: " . mysqli_error($conn);
  }
}

// Delete a timesheet entry
if (isset($_POST["id"])) {
  $id = $_POST["id"];

  // Delete the timesheet entry from the database
  $sql = "DELETE FROM timesheet WHERE id='$id'";
  if (mysqli_query($conn, $sql)) {
    echo "Timesheet entry deleted successfully.";
  } else {
    echo "Error deleting timesheet entry: " . mysqli_error($conn);
  }
}

// Export a timesheet
if (isset($_GET["id"])) {
  $id = $_GET["id"];

  // Export the timesheet to a CSV file
  $sql = "SELECT * FROM timesheet WHERE id='$id'";
  $result = mysqli_query($conn, $sql);

  if ($result) {
    $csv = array();
    $csv[] = array("Week", "Hours", "Pay Rate");
    while ($row = mysqli_fetch_assoc($result)) {
      $csv[] = $row;
    }

    // Write the CSV file to the browser
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=timesheet.csv");
    echo implode("\n", $csv);
  } else {
    echo "Error exporting timesheet: " . mysqli_error($conn);
  }
}

// Close the database connection
mysqli_close($conn);
?>
		
	
      </tbody>
    </table>
  </body>
</html>