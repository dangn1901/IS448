
<?php
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['Email'])) {
    $id = $_SESSION['id'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Connect to the database
        $conn = mysqli_connect("studentdb-maria.gl.umbc.edu", "cboyer5", "cboyer5", "cboyer5");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        
        // Set variables for the week table
        $user_id = $_SESSION['id'];
        //prevent html special characters
        $week_date = htmlspecialchars($_POST['date-selec']);
        $pay_rate = htmlspecialchars($_POST['pay-r']);

        //prevent sql injection
        $week_date = mysqli_real_escape_string($conn, $week_date);
        $pay_rate = mysqli_real_escape_string($conn, $pay_rate);

        // Execute the week table insert
        $stmt2 = $conn->prepare("INSERT INTO `timesheet_week` (`user_id`, `week_start_date`) VALUES (?, ?)");

        // Check if the statement was prepared successfully
        if (!$stmt2) {
            die("Error preparing statement: " . $conn->error);
        }

        $stmt2->bind_param("is", $user_id, $week_date);
        $stmt2->execute();
        $stmt2->close();

        // Prepare the INSERT statement for timesheets
        $stmt = $conn->prepare("INSERT INTO `timesheets` (`user_id`, `week_date`, `project_client`, `task`, `sun`, `mon`, `tues`, `wed`, `thurs`, `fri`, `sat`, `pay_rate`, `total_hours`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        // Check if the statement was prepared successfully
        if (!$stmt) {
            die("Error preparing statement: " . $conn->error);
        }

        // Get the number of rows in the form table
        $rowCount = count($_POST['project']);

        // Iterate over the submitted form data and insert each row
        for ($i = 0; $i < $rowCount; $i++) {
            //prevent html special characters
            $project_client = htmlspecialchars($_POST['project']);
            $task = htmlspecialchars($_POST['task']);
            $sun = htmlspecialchars($_POST['sun-h']);
            $mon = htmlspecialchars($_POST['mon-h']);
            $tues = htmlspecialchars($_POST['tue-h']);
            $wed = htmlspecialchars($_POST['wed-h']);
            $thurs = htmlspecialchars($_POST['thurs-h']);
            $fri = htmlspecialchars($_POST['fri-h']);
            $sat = htmlspecialchars($_POST['sat-h']);
            $total_hours = htmlspecialchars($_POST['pay-h']);

            //prevent sql injection
            $project_client = mysqli_real_escape_string($conn, $project_client);
            $task = mysqli_real_escape_string($conn, $task);
            $sun = mysqli_real_escape_string($conn, $sun);
            $mon = mysqli_real_escape_string($conn, $mon);
            $tues = mysqli_real_escape_string($conn, $tues);
            $wed = mysqli_real_escape_string($conn, $wed);
            $thurs = mysqli_real_escape_string($conn, $thurs);
            $fri = mysqli_real_escape_string($conn, $fri);
            $sat = mysqli_real_escape_string($conn, $sat);
            $total_hours = mysqli_real_escape_string($conn, $total_hours);

            $stmt->bind_param("issssssssssis", $user_id, $week_date, $project_client, $task, $sun, $mon, $tues, $wed, $thurs, $fri, $sat, $pay_rate, $total_hours);
            $stmt->execute();
        }

        $stmt->close();

        if (mysqli_affected_rows($conn) > 0) {
            echo "Record inserted successfully";
        } else {
            echo "Error inserting record: " . mysqli_error($conn);
        }

        // Close the connection
        mysqli_close($conn);

        header("location:user_dash.php");
        exit();
    }
} else {
    // Handle the case when the user is not logged in
    // Redirect or display an error message
    header("Location: login.php");
    exit();
}
?>