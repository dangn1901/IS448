<?php
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['Email'])) {
    $id = $_SESSION['id'];
?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>My dashboard</title>
    <link rel="stylesheet" href="universal.css"/>
    <link rel="stylesheet" href="dashboard.css"/>
    <script type="text/javascript" src="dashboard.js"></script>
    <script type="text/javascript" src="form_suggestions.js"></script>
    <script type="text/javascript" src=" https://ajax.googleapis.com/ajax/libs/prototype/1.7.3.0/prototype.js"></script>
</head>
  <body>
    <!--sidebar-->
    <div class="sidebar">
      <div class="logo">
        <img src="clock.svg" alt="image of a clock" />
        <h2>Timeo</h2>
      </div>
        <a href="user_dash.php">Dashboard</a>
        <a href="user_mytimesheet.html">My Timesheet</a>
        <a href="logout.php"> Logout</a>

        <div class="side-footer">
          <img src="user.svg" alt="picture of a random person" />
          <h3 class="username"><?php echo $_SESSION['name']; ?></h3>
        </div>
        <small>Version 1.0.0</small>
    </div>
    <!--Greeting the user-->
<!-- <div class="greeting"> -->
 <h1>Hello, <?php echo $_SESSION['name']; ?></h1>
<!-- </div> -->
    <!--Notification on use (should be able to click out)-->
    <div class="notification">
      <h4>Welcome to Timeo</h4>
      <div class="close" hidden>X</div>
      <div class="columns">
      <div class="col1">
        <div class="cir">1</div>
        <p class="notif-head">Ready to track time?</p>
        <p class="wrap">
          Make sure <span class="highlight">the date below is the first sunday of the week</span> , 
            <span class="highlight">Fill-in all spaces even if its a 0</span>, add tasks and press
          save when done.
        </p>
      </div>
      <div class="col2">
        <div class="cir">2</div>
        <p class="notif-head">Timesheet Report</p>
        <p class="wrap">
          Check <span class="highlight"> My Timesheets</span> to check your
          saved timesheets.
        </p>
      </div>
      <div class="col3">
        <div class="cir">3</div>
        <p class="notif-head">Functions</p>
        <p>
          You can edit and export your timesheets into an excel document!
        </p>
      </div></div>
    </div>

    <div class="timesheet-form">
      <form action="timesheet.php" class="timesheet" method="post">
        <!--week bar to select timesheet week-->
        <div class="table-top">
        <div class="week-selector">
          <div class="box-left">
            &#8592;
          </div>
          <div class="date">
          <label for="date-selec"></label>
          <input
            type="date"
            name="date-selec"
            id="date-selec"
            placeholder="2023-04-20"
            required
          /></div>
          <div class="box-right">
            &#8594;
          </div>
        </div>
        <div class="add-row">
          <input onclick="addRow(this)" type="button" value="+ Add Row">
        </div>
      </div>
        <hr />
        <!--Table-->
        <table class="timesheet-form">
          <thead>
            <tr>
              <th class="time-head">Clent/Project</th>
              <th class="time-head">Task</th>
              <th class="time-head">Sun</th>
              <th class="time-head">Mon</th>
              <th class="time-head">Tues</th>
              <th class="time-head">Wed</th>
              <th class="time-head">Thurs</th>
              <th class="time-head">Fri</th>
              <th class="time-head">Sat</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <label for="project"></label>
                <input
                  type="text"
                  name="project"
                  id="project"
                  placeholder="Project..."
                  required
                />
              </td>
              <td>
                <label for="task"></label>
                <input
                  type="text"
                  name="task"
                  id="task"
                  placeholder="task..."
                  required
                />
              </td>
              <td>
                <label for="sun-h"></label>
                <input
                  type="text"
                  name="sun-h"
                  id="sun-h"
                  placeholder="00:00"
                  oninput="timeFormat(this), calculateTotalHours()" required
                />
              </td>
              <td>
                <label for="mon-h"></label>
                <input
                  type="text"
                  name="mon-h"
                  id="mon-h"
                  placeholder="00:00"
                  oninput="timeFormat(this), calculateTotalHours()" required
                />
              </td>
              <td>
                <label for="tue-h"></label>
                <input
                  type="text"
                  name="tue-h"
                  id="tue-h"
                  placeholder="00:00"
                  oninput="timeFormat(this), calculateTotalHours()" required
                />
              </td>
              <td>
                <label for="wed-h"></label>
                <input
                  type="text"
                  name="wed-h"
                  id="wed-h"
                  placeholder="00:00"
                  oninput="timeFormat(this), calculateTotalHours()" required
                />
              </td>
              <td>
                <label for="thurs-h"></label>
                <input
                  type="text"
                  name="thurs-h"
                  id="thurs-h"
                  placeholder="00:00"
                  oninput="timeFormat(this), calculateTotalHours()" required
                />
              </td>
              <td>
                <label for="fri-h"></label>
                <input
                  type="text"
                  name="fri-h"
                  id="fri-h"
                  placeholder="00:00"
                  oninput="timeFormat(this), calculateTotalHours()" required
                />
              </td>
              <td>
                <label for="sat-h"></label>
                <input
                  type="text"
                  name="sat-h"
                  id="sat-h"
                  placeholder="00:00"
                  oninput="timeFormat(this), calculateTotalHours()" required
                />
              </td>
              <td>
                <img src="delete.svg" alt="bin" class="del-btn" onclick="deleteRow(this)" />
              </td>
            </tr>
          </tbody>
        </table>
        <hr />
        <div class="form-footer">
          <!--hours and pay rate inputs-->
          <div class="foot">
          <label for="pay-h">Total hours:</label>
          <input type="text" 
          name="pay-h" id="pay-h" 
          placeholder="00:00" 
          oninput="timeFormat(this)" /></div>

          <div class="foot">
          <label for="pay-r">Pay rate:</label>
          <input type="text" 
          name="pay-r" 
          id="pay-r" 
          placeholder="$0" 
          required
          oninput="timeFormat(this)" /></div>

          <div>
          <!--submit button named "save"-->
          <input type="submit" value="SAVE" />
        </div>
        </div>
        <script>
        document.addEventListener("DOMContentLoaded", function() {
        var inputs = document.querySelectorAll('input[type="text"]');
        inputs.forEach(function(input) {
          input.addEventListener("input", calculateTotalHours);
        });
      });

      document.getElementById('timesheet-table').addEventListener('input', handleTimeInput);
    </script>
      </form>
      <div class="suggest">
          Suggestions: <input type="text" id="suggest">
        </div>
    </div>
  </body>
</html>
<?php
} else {
    // Handle the case when the user is not logged in
    // Redirect or display an error message
    header("Location: login.php");
    exit();
}
?>