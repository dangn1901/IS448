// When the page loads, populate the table with data from the server.
window.onload = function() {
  var table = document.getElementById("table");

  // Create a new XMLHttpRequest object.
  var xhr = new XMLHttpRequest();

  // Set the request method to GET.
  xhr.open("GET", "emp_mytimesheet.php", true);

  // Send the request.
  xhr.send();

  // When the request is complete, handle the response.
  xhr.onload = function() {
    // Check the status code of the response.
    if (xhr.status === 200) {
      // The request was successful.
      // Insert the response HTML into the table.
      table.innerHTML = xhr.responseText;
    } else {
      // The request failed.
      alert("Error: " + xhr.status);
    }
  };
};


// Update a timesheet entry
function updateTimesheetEntry(id, week, hours, pay_rate) {
  // Create a new XMLHttpRequest object.
  var xhr = new XMLHttpRequest();

  // Set the request method to POST.
  xhr.open("POST", "emp_mytimesheet.php", true);

  // Set the request body.
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.send("id=" + id + "&week=" + week + "&hours=" + hours + "&pay_rate=" + pay_rate);

  // When the request is complete, handle the response.
  xhr.onload = function() {
    // Check the status code of the response.
    if (xhr.status === 200) {
      // The request was successful.
      alert("Timesheet entry updated successfully.");
    } else {
      // The request failed.
      alert("Error: " + xhr.status);
    }
  };
}


// Delete a timesheet entry
function deleteTimesheetEntry(id) {
  // Create a new XMLHttpRequest object.
  var xhr = new XMLHttpRequest();

  // Set the request method to POST.
  xhr.open("POST", "emp_mytimesheet.php", true);

  // Set the request body.
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.send("id=" + id);

  // When the request is complete, handle the response.
  xhr.onload = function() {
    // Check the status code of the response.
    if (xhr.status === 200) {
      // The request was successful.
      alert("Timesheet entry deleted successfully.");
    } else {
      // The request failed.
      alert("Error: " + xhr.status);
    }
  };
}


// Export a timesheet
function exportTimesheet(id) {
  // Create a new XMLHttpRequest object.
  var xhr = new XMLHttpRequest();

  // Set the request method to GET.
  xhr.open("GET", "emp_mytimesheet.php?id=" + id, true);

  // Send the request.
  xhr.send();

  // When the request is complete, handle the response.
  xhr.onload = function() {
    // Check the status code of the response.
    if (xhr.status === 200) {
      // The request was successful.
      // Download the CSV file.
      var blob = xhr.response;
      var link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = "timesheet.csv";
      link.click();
    } else {
      // The request failed.
      alert("Error: " + xhr.status);
    }
  };
}