window.onload = function() {
  var form = document.getElementById('create-account-form');
  form.addEventListener('submit', function(event) {
    var pass = document.getElementById('pass').value;
    var passwordError = document.getElementById('password-error');
    var email = document.getElementById('email').value;
    var emailError = document.getElementById('email-error');

    var passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!passwordPattern.test(pass)) {
      alert("Password must follow the required guidelines: 8 characters minimum, one uppercase letter, one number");
      event.preventDefault(); // Prevent form submission
      return false; // Stop further execution
    } else {
      passwordError.textContent = ""; // Clear any previous error message
    }

    if (!emailPattern.test(email)) {
      alert("Please enter a valid email address");
      event.preventDefault(); // Prevent form submission
      return false; // Stop further execution
    } else {
      emailError.textContent = ""; // Clear any previous error message
    }
  });
};
