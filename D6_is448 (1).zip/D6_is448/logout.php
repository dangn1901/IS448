<?php 

session_start();

session_unset();

session_destroy();

header("location: https://swe.umbc.edu/~cboyer5/homepage.html");
?>