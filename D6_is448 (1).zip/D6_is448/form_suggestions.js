"use strict"
window.onload = pageLoad; 
function pageLoad(){
	document.getElementById("project").onkeyup = showHint; 
}

function showHint()
{
	var inputString = document.getElementById("project").value; 
  if (inputString.length==0){ 
     $("suggest").innerHTML="";
     return;
  }
  new Ajax.Request( "form_suggestions.php", { 
    method: "get", 
    parameters: {uname:inputString},
    onSuccess: ajaxSuccess
  } );
}
//function to execute when ajax request is successful
function ajaxSuccess(ajax){
	$("suggest").value=ajax.responseText;
}
//function to execute when ajax request is unsuccessful
function ajaxFailure(){
	alert("Ajax request failed");
}