<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get input values
    $email = $_POST['Email'];
    $password = $_POST['pass'];

    // Connect to the database
    $conn = mysqli_connect("studentdb-maria.gl.umbc.edu", "cboyer5", "cboyer5", "cboyer5");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Create query
    $query = "SELECT * FROM Login WHERE email = '$email' AND password = '$password'";

    // Execute query
    $result = mysqli_query($conn, $query);

    // Check if user exists
    if (mysqli_num_rows($result) > 0) {
        // User is authenticated, set session variables and redirect to homepage
        $row = mysqli_fetch_assoc($result);
	
	 
	if ($row['email'] === $email && $row['password'] === $password) {
        $_SESSION['id'] = $row['id'];
		$_SESSION['name'] = $row['name'];
        $_SESSION['Email'] = $row['email'];
        $_SESSION['pass'] = $row['password'];

        header("location: user_dash.php");
         exit();
	}
    } else {
        // Authentication failed, show error message
        echo( "Invalid email or password");
    }
	

    // Close connection
    mysqli_close($conn);
}
?>
